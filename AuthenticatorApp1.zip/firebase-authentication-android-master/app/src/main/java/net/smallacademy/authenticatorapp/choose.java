package net.smallacademy.authenticatorapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class choose extends AppCompatActivity {
    ImageButton jobseeker;
    ImageButton recuiter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choose);

        jobseeker = findViewById(R.id.jobseeker);
        recuiter = findViewById(R.id.recruiter);


        jobseeker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(),Register.class));
                startActivity(new Intent(getApplicationContext(), Register.class));

            }
        });


        recuiter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(),Register.class));
                startActivity(new Intent(getApplicationContext(), provider_registry.class));

            }
        });
    }
}
